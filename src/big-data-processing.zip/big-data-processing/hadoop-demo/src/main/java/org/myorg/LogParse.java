package org.myorg;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import au.com.bytecode.opencsv.CSVParser;

public class LogParse {

  public static class ParseMapper 
       extends Mapper<Object, Text, NullWritable,Text >{
    
    private Text word = new Text();
      
    public void map(Object key, Text value, Context context
                    ) throws IOException, InterruptedException {
      CSVParser parse = new CSVParser(' ','\"');
	  String sp[]=parse.parseLine(value.toString());
	  int spSize=sp.length;
	  StringBuffer rec= new StringBuffer();
	  for(int i=0;i<spSize;i++){
		  rec.append(sp[i]);
		  if(i!=(spSize-1))
			  rec.append("\t");
	  }
	  word.set(rec.toString());
      context.write(NullWritable.get(), word);
    }
   }
  
    public static void main(String[] args) throws Exception {
    
    GenericOptionsParser gparse=new GenericOptionsParser(args);
    Configuration conf =gparse.getConfiguration();
   // = new GenericOptionsParser(args).getRemainingArgs();
    
    
    String[] otherArgs =gparse.getRemainingArgs();
    if (otherArgs.length != 2) {
      System.err.println("Usage: LogParse <in> <out>");
      System.exit(2);
    }
    Job job = new Job(conf, "Log Parse");
    job.setJarByClass(LogParse.class);
    job.setMapperClass(ParseMapper.class);
    job.setOutputValueClass(Text.class);
    job.setOutputKeyClass(NullWritable.class);
    job.setMapOutputValueClass(Text.class);
    job.setMapOutputKeyClass(NullWritable.class);
    FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
    FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));
    System.exit(job.waitForCompletion(true) ? 0 : 1);
  }
}
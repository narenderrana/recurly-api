package com.test;

import java.util.List;

public class UserWrapper {

	public List<User> getList() {
		return list;
	}

	public void setList(List<User> list) {
		this.list = list;
	}

	List<User> list;
	
	
	
}

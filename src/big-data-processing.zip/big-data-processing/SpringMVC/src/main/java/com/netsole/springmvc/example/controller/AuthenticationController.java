package com.netsole.springmvc.example.controller;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.authentication.dao.SaltSource;
import org.springframework.security.authentication.encoding.PasswordEncoder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.netsole.springmvc.example.modal.Users;

@Controller
public class AuthenticationController  {
	
	@Autowired
	UserDetailsService userService ;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Autowired
	SaltSource saltSource;
	

@RequestMapping("*")
 public String check(Authentication authentication){
	
	try{	
		if(authentication!=null){		
				Users user=(Users)authentication.getPrincipal();
					if(user!=null) return "redirect:/sucess";
						else return "redirect:/login";
								}
		}catch(Exception exception){exception.printStackTrace();}
		 
		 return "redirect:/login";
	 }
	
 @RequestMapping("/login")
 public String authenticated(){
	 
	UserDetails user= userService.loadUserByUsername("narender.rana+57@netsolutionsindia.com");
	 System.out.println("*********:password343:-------->"+passwordEncoder.encodePassword("userUser1",saltSource.getSalt(user)));
	 
	 
	 return "/user/signin";
 }
 
 
 @RequestMapping("/sucess")
 public String onSucess(Authentication auth){
	 
	// User user=(User)auth.getPrincipal();
	 Users user=(Users)auth.getPrincipal();
	 //System.out.println("password:-------->"+passwordEncoder.encodePassword("userUser1",saltSource.getSalt(user)));
	 userService.loadUserByUsername("narender.rana+57@netsolutionsindia.com");
	 
	 return "/user/dashboard";
 }
 
 @RequestMapping("/dashboard")
 public String dashboard(){
	 
	 return "/user/dashboard";
 }
 @RequestMapping("/badcrediantial")
 public String onFailure(){
	 
	 return "/user/signin";
 }
 
 @RequestMapping("/signup")
 public String onSignUp(){
	 
	 return "/user/signup";
 }
 
 @Secured(value="admin")
 @RequestMapping("/report")
 public String onReport(){
	 
	 return "/user/report";
 }
 
 @RequestMapping("/charts")
 public String onChart(){
	 
	 return "/user/chart";
 }

 @RequestMapping("/unauthorized")
 public String onUnauthorizedAccess(HttpSession session){
	 
	 session.setAttribute("test", "test");
	 System.out.println("*********:password343----:-------->");
	 
	 return "/user/unauthorized";
 }
 @RequestMapping("/invalidSession")
 public String OnInvalidSession(HttpSession session){
	 session.setAttribute("test", "test"+21212+"---"+2323);
	 return "/user/invalidSession";
 }
 
}

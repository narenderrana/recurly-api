package com.netsole.springmvc.example.aop;

public   class Abstract {

	static String   abc="static/non class can acess";
	String nostatic="non static only can access this";
	
	
	public  static void hekko(){
		
		
	}
	
	 public static void main(String[] args) {
		  System.out.println(StaticClass.hello());
	}
	
	 static class  StaticClass{
		
		  public int a=10;
		  public static int hello(){
			  System.out.println("Hi helllllllllllllloooo"+abc);return 0;
		  }
		  public static void main(String[] args) {
			
		}
		
	}
	   class  NonStaticClass{
			
		  public   int a=10;
		  public   int hello(){
			  System.out.println("Hi helllllllllllllloooo"+abc+nostatic);return 0;
		  }
		
	}
}

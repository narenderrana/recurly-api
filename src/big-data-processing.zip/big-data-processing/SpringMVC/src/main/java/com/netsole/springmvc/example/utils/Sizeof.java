package com.netsole.springmvc.example.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class Sizeof
{
	private static int count=0; 
    public static void main (String [] args) throws Exception
    {
         
         System.out.println(show("ABCD"));
       
    }
    
     public static   String show(String xyz){
    	  System.out.println(xyz+":"+(++count));
    	if(xyz.length()<=1||xyz==null){
    		return xyz;
    	}
    	
    	return show(xyz.substring(1)+xyz.charAt(0));
    }
    
}  
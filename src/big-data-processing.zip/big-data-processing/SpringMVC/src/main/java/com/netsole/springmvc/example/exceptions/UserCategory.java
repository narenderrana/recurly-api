package com.netsole.springmvc.example.exceptions;

public class UserCategory {

	public String getDetail()  throws Error {
		System.out.println("Stock");
		
		if(1==1){
		throw new Error();
		}
		
		return null;
	}
}

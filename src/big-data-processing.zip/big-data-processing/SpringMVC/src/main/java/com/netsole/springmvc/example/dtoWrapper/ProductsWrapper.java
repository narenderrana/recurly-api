package com.netsole.springmvc.example.dtoWrapper;

import com.netsole.springmvc.example.dto.Products;

public class ProductsWrapper {
 private Products products;

public Products getProducts() {
	return products;
}

public void setProducts(Products products) {
	this.products = products;
}
 
}

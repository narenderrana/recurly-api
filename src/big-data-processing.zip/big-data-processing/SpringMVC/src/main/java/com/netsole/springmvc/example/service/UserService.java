package com.netsole.springmvc.example.service;


import com.netsole.springmvc.example.model.Users;

public interface UserService {
	
	public Users getUserDetailById(Long userId) ;
	public Users getUserDetailById(Long userId,Users user) ;
	public boolean  addUsers() throws RuntimeException ;
	public boolean addUsers(Users user) throws  Throwable;
	public boolean divideByZiro() ;
	 
}

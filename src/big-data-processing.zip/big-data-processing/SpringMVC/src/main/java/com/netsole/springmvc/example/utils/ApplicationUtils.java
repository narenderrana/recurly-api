package com.netsole.springmvc.example.utils;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.netsole.springmvc.example.aop.Logger;

@Component("applicationUtils")
@Logger
public class ApplicationUtils {

	
	static public  boolean userStaticMetghod() {
		 System.out.println("Excecuting com.netsole.springmvc.example.utils.ApplicationUtils.userStaticMetghod");
		return false;
	}
	  public  Map userNoNStaticMetghod() {
		 System.out.println("Excecuting com.netsole.springmvc.example.utils.ApplicationUtils.userNoNStaticMetghod");
		 
		 
		return new HashMap() ;
	}
	  
	   boolean userDefaultMetghod() {
			 System.out.println("Excecuting com.netsole.springmvc.example.utils.ApplicationUtils.userDefaultMetghod");
			return false;
		}
	  public final   boolean userFinalMetghod() {
			 System.out.println("Excecuting com.netsole.springmvc.example.utils.ApplicationUtils.userPublicFinalMetghod");
			return false;
		}
	     
	
}

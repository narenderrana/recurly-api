package com.netsole.springmvc.example.aop;

import javax.servlet.http.HttpServlet;

 

public class MyServlet  extends  HttpServlet {

}

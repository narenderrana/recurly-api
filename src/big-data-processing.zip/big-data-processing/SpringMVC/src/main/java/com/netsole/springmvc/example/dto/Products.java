package com.netsole.springmvc.example.dto;

import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnore;

public class Products {

 String activity_id;	
 String product_id;
 String Product_name;
 String uuid;
 Date activity_date;
 String api_key;
 
 @JsonIgnore
 String status;
 
 
public String getProduct_id() {
	return product_id;
}
public void setProduct_id(String product_id) {
	this.product_id = product_id;
}
public String getProduct_name() {
	return Product_name;
}
public void setProduct_name(String product_name) {
	Product_name = product_name;
}
public String getUuid() {
	return uuid;
}
public void setUuid(String uuid) {
	this.uuid = uuid;
}
public Date getActivity_date() {
	return activity_date;
}
public void setActivity_date(Date activity_date) {
	this.activity_date = activity_date;
}
public String getApi_key() {
	return api_key;
}
public void setApi_key(String api_key) {
	this.api_key = api_key;
}
 
public String getActivity_id() {
	return activity_id;
}
public void setActivity_id(String activity_id) {
	this.activity_id = activity_id;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
	
	
}

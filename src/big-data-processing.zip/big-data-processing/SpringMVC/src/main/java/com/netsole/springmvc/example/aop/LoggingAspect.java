package com.netsole.springmvc.example.aop;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.lang.Boolean;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component 
public class LoggingAspect {
	
	private static final Runtime s_runtime = Runtime.getRuntime();
	
   public  static Map<String,Integer> methodList=new HashMap<String,Integer>();
 
	 
	/*@Before("execution(* com.netsole.springmvc.example.service.*.*(..))")
	public void logBefore(JoinPoint joinPoint)   {

		System.out.println("logBefore is running :"+joinPoint.getSignature().getName()+",argumets:"+Arrays.toString(joinPoint.getArgs()));
		//joinPoint.proceed();
		 

	}*/
	
	/*@AfterReturning(pointcut="execution(* com.netsole.springmvc.example.service.*.*(..))",returning= "result")
	public void logAfterReturning(JoinPoint joinPoint,Object result)   {

		System.out.println("logAfterReturning is running :"+joinPoint.getSignature().getName()+",argumets:"+Arrays.toString(joinPoint.getArgs())+"returning :"+result);
		//joinPoint.proceed();
		 

	}
	
	
 
	@AfterThrowing(pointcut="execution(* com.netsole.springmvc.example.service.*.*(..))",throwing= "error")
	public void logAfterThrowing(JoinPoint joinPoint,Throwable error)   {

		System.out.println("logAfterThrowing is running :"+joinPoint.getSignature().getName()+",argumets:"+Arrays.toString(joinPoint.getArgs())+"throwing :"+error.getMessage());
		//joinPoint.proceed();
		 

	}*/
	/*
	@After("execution(* com.netsole.springmvc.example.service.*.*(..))")
	public void logAfter(JoinPoint joinPoint)  {

		if(joinPoint!=null)
		System.out.println("logAfter is running :"+joinPoint.getSignature().getName()+",argumets:"+Arrays.toString(joinPoint.getArgs()));
		//joinPoint.proceed();	/*@Before("execution(* com.mkyong.customer.bo.CustomerBo.addCustomer(..))")
	public void logBefore(JoinPoint joinPoint) {

		System.out.println("logBefore() is running!");
		System.out.println("hijacked : " + joinPoint.getSignature().getName());
		System.out.println("******");
	}*/

	/*@After("execution(* com.mkyong.customer.bo.CustomerBo.addCustomer(..))")
	public void logAfter(JoinPoint joinPoint) {

		System.out.println("logAfter() is running!");
		System.out.println("hijacked : " + joinPoint.getSignature().getName());
		System.out.println("******");

	}*/
	
	/*@AfterReturning(
			pointcut = "execution(* com.mkyong.customer.bo.CustomerBo.addCustomerReturnValue(..))",
			returning= "result")
	public void logAfterReturning(JoinPoint joinPoint, Object result) {

		System.out.println("logAfterReturning() is running!");
		System.out.println("hijacked : " + joinPoint.getSignature().getName());
		System.out.println("Method returned value is : " + result);
		System.out.println("******");

	}*/
	
	/*@AfterThrowing(
			pointcut = "execution(* com.mkyong.customer.bo.CustomerBo.addCustomerThrowException(..))",
			throwing= "error")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable error) {

		System.out.println("logAfterThrowing() is running!");
		System.out.println("hijacked : " + joinPoint.getSignature().getName());
		System.out.println("Exception : " + error);
		System.out.println("******");

	} */
		 
/*@AfterReturning(
			pointcut = "execution(* com.netsole.springmvc.example.service.*.*(..))",
			returning= "result")
	public void logAfterReturning(JoinPoint joinPoint, Object result) {
 
	System.out.println("logAround is running before:"+joinPoint.getSignature().getName()+",argumets:"+Arrays.toString(joinPoint.getArgs())+"result:"+result);
	s_runtime.totalMemory();

	}*/
 
	/*
	@Around("execution(* com.netsole.springmvc.example.service.*.*(..))")
	public void logAround(ProceedingJoinPoint  joinPoint) throws Throwable {
		//methodList.put(joinPoint.getSignature().getName(), value)
		System.out.println("logAround is running before:"+joinPoint.getSignature().getName()+",argumets:"+Arrays.toString(joinPoint.getArgs()));
		joinPoint.proceed(); 
		System.out.println("logAround is running after :"+joinPoint.getSignature().getName()+",argumets:"+Arrays.toString(joinPoint.getArgs()));
				 

	} 
	
	/*@Around("execution(* com.netsole.springmvc.example.service.UserService.addUsers(..))")
	public void addMethodAround(ProceedingJoinPoint joinPoint ) throws Throwable {

		System.out.println("addMethodAround is running before :");
		try{
		joinPoint.proceed(); }
		catch(Exception e){
			e.printStackTrace();
			
		}
		System.out.println("addMethodAround is running after:");	
	 
		 

	}*/
      //@Before("inWebLayer()")
	  //@Before("execution(* com.netsole.springmvc.example.service.UserService.addUsers(..))")
	//@Before("within(com.netsole.springmvc.example.service.*.*)")
    /*The execution of any public method:*/
       //@Before("execution(* com.netsole.springmvc.example.utils.ApplicationUtils.*(..))")
    // @Before("execution(public java.util.Map com.netsole.springmvc.example.utils.ApplicationUtils.*(..))")
    // @Around("execution(public java.util.Map com.netsole.springmvc.example.utils.*.*(..))")
    //@Before("execution(public * com.netsole.springmvc.example.service.*.*(..)) or execution(public java.util.Map com.netsole.springmvc.example.utils.*.*(..))")
   //@Before("this(com.netsole.springmvc.example.service.UserService)")
   //@Before("target(com.netsole.springmvc.example.service.UserService)")
   //@Before("args(java.io.Serializable) && this(com.netsole.springmvc.example.service.UserService)")
   //@Before("args(java.io.Serializable,com.netsole.springmvc.example.utils.Interceptable) && this(com.netsole.springmvc.example.service.UserService)")
   //@Before("@target(com.netsole.springmvc.example.aop.Logger)")//will be exception
   //@Before("@target(com.netsole.springmvc.example.aop.Logger) && within(com.netsole.springmvc.example.service.*.*)")
   @Before("@within(com.netsole.springmvc.example.aop.Logger)")
    //@Before("@annotation(com.netsole.springmvc.example.aop.Idempotent)")
   // @Before("bean(userService)")
   //@Before("bean(userService) or bean(applicationUtils)")
   public void beforeAdwise(JoinPoint joinPoint ) throws Throwable {

		System.out.println("beforeAdwise is running before :"+joinPoint.getSignature().getName());
	  

	}

	/*@Pointcut("execution(public * com.netsole.springmvc.example.utils.ApplicationUtils.*(..))")
	public void staticPointCut(){
		 System.out.println("staticPointCut is running pintcut :");
		
	}*/
     /**
      * A join point is in the web layer if the method is defined
      * in a type in the com.netsole.springmvc.example.service or any sub-package
      * under that.
      */
     @Pointcut("within(com.netsole.springmvc.example.service..*)")
     public void inWebLayer() {}

 
  
	
}
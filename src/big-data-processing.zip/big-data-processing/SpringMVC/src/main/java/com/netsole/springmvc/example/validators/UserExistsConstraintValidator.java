package com.netsole.springmvc.example.validators;

import java.lang.annotation.Annotation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class UserExistsConstraintValidator implements ConstraintValidator <UserExistsConstraint,String>{

	@Override
	public void initialize(UserExistsConstraint constraintAnnotation) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		// TODO Auto-generated method stub
		return false;
	}
	 

 
	}
	 
 

package com.netsole.springmvc.example.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class Persons {
    
	@Autowired
	private Address address;
	@Autowired
	private Address address2;
	
	@Autowired
	public Persons(Address adress){
		this.address = address;
	}
	public Address getAddress() {
		return address;
	}
    @Autowired
	public void setAddress(Address address) {
		this.address = address;
	}
    
    
	public Address getAddress2() {
		return address2;
	}
	
 
	public Persons show(){
		
		
		return null;
	}
	
}

package com.netsole.springmvc.example.controller;
import java.lang.annotation.Annotation;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

 
public class WelcomeController extends AbstractController  {

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model = new ModelAndView("hello");
		model.addObject("message", "WelcomeController");
		System.out.println("request processing from WelcomeController");
		
		return model;
	}
 

}
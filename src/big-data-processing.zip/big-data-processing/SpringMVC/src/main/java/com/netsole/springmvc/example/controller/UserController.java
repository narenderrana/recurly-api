package com.netsole.springmvc.example.controller;

 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.netsole.springmvc.example.dto.Products;
import com.netsole.springmvc.example.dtoWrapper.ProductsWrapper;
import com.netsole.springmvc.example.kafka.Producer;
import com.netsole.springmvc.example.model.AppUsers;
import com.netsole.springmvc.example.model.Users;
import com.netsole.springmvc.example.service.UserService;
import com.netsole.springmvc.example.utils.ApplicationUtils;
import com.netsole.springmvc.example.validators.UserValidator;
 

@Controller
@RequestMapping("/user/**")
public class UserController extends MultiActionController{
	 List  countryList=null;
	 Map countryMap=null;
	 
	 @Autowired
	 UserService userService;
	 
	 @Autowired
	 ApplicationUtils applicationUtils;
	 
	 @Autowired
	 Producer producer;
	 

	 
	 @InitBinder
	 void initialize(WebDataBinder binder){
		 countryList= new ArrayList<String>();
		    countryList.add("Angola");
		    countryList.add("Anguilla");
		    countryList.add("Antarctica");
		    countryList.add("Argentina");
		    countryList.add("Armenia");
		    countryList.add("India");
		    countryList.add("Aruba");
		    countryList.add("Australia");
		    countryMap= new HashMap<String,String>();
		    countryMap.put("Angola","AN");
		    countryMap.put("Anguilla","AN");
		    countryMap.put("Antarctica","AN");
		    countryMap.put("Argentina","AR");
		    countryMap.put("Armenia","AR");
		    countryMap.put("India","IN");
		    countryMap.put("Aruba","AR");
		    countryMap.put("Australia","AU"); 
		   // binder.setValidator(new UserValidator());
	 }
	
	@RequestMapping("/signup")
	public String  signup(
			@ModelAttribute("userForm") Users  userForm,
			@RequestParam(value="name",defaultValue="nare",required=false) String name,
			@CookieValue(value="isHomePage",defaultValue="true",required=false) boolean isHOmePage,
			ModelMap map
			
			) throws Exception {
			//Users userForm=new Users();
		    userForm.setFirstName("Narender");
		    userForm.setLastName("Rana");
		    userForm.setGender("Male");
		    userForm.setLocation("Chandigarh ,India");
		    userForm.setPassword("password");
		    userForm.setUserInterest("criket");
		    userForm.setCountry("India");
		    userForm.setAddress("address");
		    userForm.setEmail("narender.rana@netsolutionsindia.com");
		    userForm.setPhoneNo(919592840427L);
		    userForm.setSalary(16256);
		    userForm.setAcceptTerms(false);
		    
		   
		   
		    
		    String country[]={"Australia","India","Anguilla","Aruba"};
		    
			map.put("countryList", countryList);
			map.put("countryMap", countryMap);
			map.put("countries", country);
			map.put("userForm", userForm);
			
			
			userService.addUsers();
			//map.addAttribute("userForm",userForm);
			return  "user/user_signup";
				
		}
	
	 
	
	@RequestMapping("add")
	public ModelAndView  add(HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam(value="name",defaultValue="nare",required=false) String name,
			@CookieValue(value="isHomePage",defaultValue="true",required=false) boolean isHOmePage
			 
			
					 
			) throws Exception {
			System.out.println("Main mehod proccesed");
			return new ModelAndView("add", "message","add() method from UserController");
				
		}
	@RequestMapping("/testaddCustomer")
	public ModelAndView testaddCustomer(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
		
		return new ModelAndView("hello", "message","add() method from UserController");
			
	}
	@RequestMapping("/delete")
	public ModelAndView  delete(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
			
		return new ModelAndView("delete", "message","delete() method from UserController");
				
	}
	
	@RequestMapping("/update")
	public ModelAndView  update(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
			
		return new ModelAndView("update", "message","update() method from UserController");
				
	}
	@RequestMapping("/insert")
	public ModelAndView  insert(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
				
		return new ModelAndView("insert", "message","list() method from UserController");
					
	}
 
	@RequestMapping("/map")
	public Map  mymap(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
		Map list=new HashMap();
				list.put("id", "123");
				list.put("name", "user name");
				
				
		return list;
					
	}
	
	@RequestMapping("/list")
	public List  mylist(HttpServletRequest request,
		HttpServletResponse response)  {
		List list=new ArrayList();
				list.add("123");
				list.add("user name");
				//try{
				userService.getUserDetailById(121212L);
				Users user=new Users();
				userService.addUsers();
				//userService.addUsers(user);
				//userService.divideByZiro();
				//userService.getUserDetailById(121212L,user);
				applicationUtils.userStaticMetghod();
				applicationUtils.userNoNStaticMetghod();
				applicationUtils.userFinalMetghod();
				 
				
				//}catch(Exception e){System.out.println(e.getMessage());}
				 
				 
		return list;
					
	}
	@RequestMapping("/userdetail")
	public List<AppUsers>  userDEeail(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
		AppUsers user=new AppUsers();
		user.setId(100L);
		user.setName("User name");
		
		List result=new ArrayList();
		result.add(user);
		
				
				
		return result;
					
	}
	@RequestMapping("/insertUser")
	public ModelAndView insertUser(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
				
		return new ModelAndView("insertUser", "message","insertUser() method from UserController");
					
	}
	@RequestMapping("/updateUser")
	public ModelAndView updateUser(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
				
		return new ModelAndView("updateUser", "message","updateUser() method from UserController");
					
	}
	@RequestMapping("/addUser")
	public String addUser(ModelMap map,HttpServletRequest request,
		HttpServletResponse response) throws Exception {
		Map map1=new HashMap();
		map1.put("name", "netsole");
		map1.put("id", "3000");
		map1.put("address", "ABC");
		
		map.put( "message","addUser() method from UserController");
		map.put( "mymap",map1);
		
		
		return  "addUser";
					
	}
	@RequestMapping("/deleteUser")
	public ModelAndView deleteUser(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
				
		return new ModelAndView("deleteUser", "message","deleteUser() method from UserController");
			
		
	}
	@RequestMapping("/updateCustomer")
	public ModelAndView updateCustomer(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
				
		return new ModelAndView("updateCustomer", "message","updateCustomer() method from UserController");
					
	}
	@RequestMapping("/addCustomer")
	public String addCustomer(ModelMap map,HttpServletRequest request,
		HttpServletResponse response) throws Exception {
		Map map1=new HashMap();
		map1.put("name", "netsole");
		map1.put("id", "3000");
		map1.put("address", "ABC");
		
		map.put( "message","addCustomer() method from UserController");
		map.put( "mymap",map1);
		
		
		return  "addCustomer";
					
	}
	@RequestMapping("/deleteCustomer")
	public ModelAndView deleteCustomer(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
				
		return new ModelAndView("deleteCustomer", "message","deleteCustomer() method from UserController");
					
	}
	
	@RequestMapping("/push_activity_info")
	public Products   pushActivityInfo(HttpServletRequest request,
			HttpServletResponse response,ProductsWrapper  productsWrap 
			) throws Exception {
			 System.out.println(productsWrap.getProducts());
			 Products product=productsWrap.getProducts();
			 product.setActivity_id(product.getActivity_id()+UUID.randomUUID().toString());
			 producer.send(product);
			 Map<String, String> map=new HashMap<String, String>();
			 map.put("status", "ok");
			 
			return  product;
				
		}
	
	
	@RequestMapping("/activityinfo")
	public String   activityinfo(HttpServletRequest request,
			HttpServletResponse response 
			) throws Exception {
			 
			 
			return  "activityinfo";
				
		}
	
}
package com.netsole.springmvc.example.validators;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.netsole.springmvc.example.model.Users;

public class UserValidator  implements Validator {

 

	@Override
	public void validate(Object target, Errors errors) {
		System.out.println("Excecuting UserValidator.validate(...,..)");
		// TODO Auto-generated method stub
		 
		 ValidationUtils.rejectIfEmpty(errors, "firstName", "NotEmpty.userForm.firstName");
		 ValidationUtils.rejectIfEmpty(errors, "lastName", "NotEmpty.userForm.lastName");
		 
		 
		 Users user = (Users) target;
	        if (user.getSalary()< 0 ) {
	        	errors.rejectValue("salary", "Range.userForm.salary");
	        } else if (user.getSalary() > 150) {
	        	errors.rejectValue("salary", "Range.userForm.salary");
	        }
		
	}

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		 return Users.class.equals(clazz);
	}

}

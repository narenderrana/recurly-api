package com.netsole.springmvc.example.validators;

 

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

 

 
 

public class LocationValidator  implements    ConstraintValidator<UserLocation,String> {

	/*@Autowired
	UserService userService */
	String locationName;
	
	@Override
	public void initialize(UserLocation constraintAnnotation) {
		// TODO Auto-generated method stub
		//this.locationName=constraintAnnotation.value();
		
	}

	@Override
	public boolean isValid(String memberLocation, ConstraintValidatorContext context) {
		// TODO Auto-generated method stub
		System.out.println(locationName+memberLocation);
		 if(memberLocation.contains(",")) return true;
		
		return false;
	}

	 

	 

	
}

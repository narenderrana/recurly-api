package com.netsole.springmvc.example.dao;

import org.springframework.stereotype.Component;

@Component("address")
public class Address {

	
	
	
	
}

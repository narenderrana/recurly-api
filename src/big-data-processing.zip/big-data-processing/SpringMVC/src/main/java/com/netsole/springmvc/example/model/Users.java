package com.netsole.springmvc.example.model;

import java.io.Serializable;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Range;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.netsole.springmvc.example.aop.Logger;
import com.netsole.springmvc.example.utils.Interceptable;
import com.netsole.springmvc.example.validators.UserLocation;

 
public class Users implements Serializable ,Interceptable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@NotEmpty
	String firstName;
	@NotEmpty
	String password;
	@NotEmpty
	String lastName;
	
	@NotEmpty
	@UserLocation 
	String location;
	@NotEmpty
    String gender;
	@NotEmpty
	String country;
	@NotEmpty
	String userInterest;
	@NotEmpty
	String address;
	@Email
	String email;
	
	
	MultipartFile file;
  
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	@Range(min = 1, max = 150)
    long phoneNo;
    
	@Range(min = 1, max = 150)
	int salary;
	
	 
	boolean acceptTerms;
	
	
	
	public String getFirstName() {
		return firstName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getUserInterest() {
		return userInterest;
	}
	public void setUserInterest(String userInterest) {
		this.userInterest = userInterest;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public boolean isAcceptTerms() {
		return acceptTerms;
	}
	public void setAcceptTerms(boolean acceptTerms) {
		this.acceptTerms = acceptTerms;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	 
	
	
    
	

}

package com.netsole.springmvc.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.netsole.springmvc.example.dao.impl.UsersHome;
import com.netsole.springmvc.example.modal.Users;

@Service("userDetailsService")
public class UserDetailService implements UserDetailsService {

	@Autowired
	UsersHome userDao;
	
	@Override
	public UserDetails loadUserByUsername(String userName)
			throws UsernameNotFoundException, DataAccessException {
		Users user=new Users();
		user.setEmail(userName);
	  List<Users>  userList=userDao.findByProperties("email", userName);
	  //if(userList.size()>0)
		//return userList.get(0);
	  
		// TODO Auto-generated method stub
	 
		return null;
	}

}

package com.netsole.springmvc.example.service.impl;

import org.springframework.stereotype.Service;

import com.netsole.springmvc.example.aop.Idempotent;
import com.netsole.springmvc.example.aop.Logger;
import com.netsole.springmvc.example.model.Users;
import com.netsole.springmvc.example.service.UserService;

@Service("userService")
@Logger
public class UserServicesImpl  implements UserService{

	@Override
	public Users getUserDetailById(Long userId) {
		
		Users user=new Users();
		user.setFirstName("Narender Rana");
		System.out.println("Executing com.netsole.springmvc.example.service.impl.getUserDetailById");
		return user ;
	}

	@Override
	@Idempotent
	public boolean addUsers() throws NullPointerException {
		Users user=new Users();
		System.out.println("Executing com.netsole.springmvc.example.service.impl.addUsers:"+user);
		
		if(user==null)
		{
			
			int abc=1/0;
		}
		// TODO Auto-generated method stub
		 
 
		return true;
	}

	@Override
	public boolean divideByZiro() {
		
	
		Users user=null;
		System.out.println("Executing com.netsole.springmvc.example.service.impl.divideByZiro:"+user);
		
		if(user==null)
		{
			
			int abc=1/0;
		}
		// TODO Auto-generated method stub
		 
 
		return true;
		 
	}

	@Override
	public boolean addUsers(Users user) throws Exception{ 
		System.out.println("Executing com.netsole.springmvc.example.service.impl.addUsers(Users user):"+user);
		return false;
	}

	@Override
	public Users getUserDetailById(Long userId, Users user) {
		System.out.println("Executing com.netsole.springmvc.example.service.impl.addUsers(Long userId, Users user)");
		return null;
	}


}

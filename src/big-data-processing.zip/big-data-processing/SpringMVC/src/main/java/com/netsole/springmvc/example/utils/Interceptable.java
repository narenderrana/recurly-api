package com.netsole.springmvc.example.utils;

public interface Interceptable {
/*marker interface*/
}

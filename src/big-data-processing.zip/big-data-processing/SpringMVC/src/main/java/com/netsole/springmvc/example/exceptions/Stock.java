package com.netsole.springmvc.example.exceptions;

public class Stock  extends UserCategory{
	
@Override
public String getDetail()  {
	// TODO Auto-generated method stub
	System.out.println("Stock");
return null;	 
}


public static void main(String[] args) {
	Stock stock=new Stock();
	
 
	
	UserCategory cat=new Stock();;
	cat.getDetail();
	
}
}

package com.netsole.springmvc.example.controller;

 
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

public class CustomerController extends MultiActionController{
	
	
	public ModelAndView  add(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
			
			return new ModelAndView("add", "message","add() method");
				
		}
	public ModelAndView  delete(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
			
			return new ModelAndView("delete", "message","delete() method");
				
		}
	public ModelAndView insert(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
				
			return new ModelAndView("insert", "message","insert() method");
					
		}
	public ModelAndView update(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
				
			return new ModelAndView("update", "message","update() method");
					
		}
	public ModelAndView testaddCustomer(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
		
		return new ModelAndView("hello", "message","testaddCustomer() ");
			
	}
	
	public ModelAndView testdeleteCustomer(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
			
		return new ModelAndView("hello", "message","testdeleteCustomer() method");
				
	}
	
	public ModelAndView testupdateCustomer(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
			
		return new ModelAndView("hello", "message","testupdateCustomer() method");
				
	}
	
	public ModelAndView testlistCustomer(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
				
		return new ModelAndView("hello", "message","testlistCustomer() method");
					
	}
	
}
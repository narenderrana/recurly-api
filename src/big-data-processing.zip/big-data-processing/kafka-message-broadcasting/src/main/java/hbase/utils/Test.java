package hbase.utils;



import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.hbql.client.HBatch;
import org.apache.hadoop.hbase.hbql.client.HConnection;
import org.apache.hadoop.hbase.hbql.client.HConnectionManager;
import org.apache.hadoop.hbase.hbql.client.HPreparedStatement;
import org.apache.hadoop.hbase.hbql.client.HResultSet;
 
import org.apache.hadoop.hbase.hbql.client.Util;
 

public class Test {
public static void main(String[] args) throws Exception {
	
	
	
	// Get a connection to HBase
	 Configuration config = HBaseConfiguration.create();
	 config.set("hbase.zookeeper.quorum", "test-desktop");
     config.set("hbase.zookeeper.property.clientPort", "2181");
     config.set("hbase.master", "192.168.0.46:60000");
     try {
         HBaseAdmin.checkHBaseAvailable(config);
     } catch (MasterNotRunningException e) {
         System.out.println("HBase is not running.");
         System.exit(1);
     }
    HConnection conn = HConnectionManager.newConnection(config);
    

    conn.execute("CREATE TEMP MAPPING demo2 FOR TABLE example2"
                 + "("
                 + "keyval KEY, "
                 + "f1 ("
                 + "  val1 STRING ALIAS val1, "
                 + "  val2 INT ALIAS val2, "
                 + "  val3 STRING ALIAS val3 DEFAULT 'This is a default value' "
                 + "))");

    // Clean up table
    if (!conn.tableExists("example2"))
        conn.execute("CREATE TABLE example2 (f1())");
    else
        conn.execute("DELETE FROM demo2");

    // Add some records using an INSERT stmt
    HPreparedStatement stmt = conn.prepareStatement("INSERT INTO demo2 " +
                                                    "(keyval, val1, val2, val3) VALUES " +
                                                    "(ZEROPAD(:key, 10), :val1, :val2, DEFAULT)");

    for (int i = 0; i < 5; i++) {
        stmt.setParameter("key", i);
        stmt.setParameter("val1", "Value: " + i);
        stmt.setParameter("val2", i);
        stmt.execute();
    }

 
    conn.close();

	
	
}
}

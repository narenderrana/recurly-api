package hbase.utils;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTableInterface;

public class HBaseAdminManager {
 private  static	 Configuration configuration=null;
 public static Configuration getConfiguration(){
	 
	 return configuration;
 }
 private static HBaseAdmin admin = null;
	public static HBaseAdmin	getHBaseAdmin(){
		
		if(admin==null){
		
	     try {
	         HBaseAdmin.checkHBaseAvailable(getConfiguration());
	         admin = new HBaseAdmin(configuration);
	     } catch (Exception e) {
	         System.out.println("HBase is not running.");
	         System.exit(1);
	     }
		}
	 
	    return admin;
	}
 
	
	
	 static{
		 
		 Configuration config = HBaseConfiguration.create();
		 config.set("hbase.zookeeper.quorum", "test-desktop");
	     config.set("hbase.zookeeper.property.clientPort", "2181");
	     config.set("hbase.master", "192.168.0.46:60000");
	     configuration=config;
	 }	
	
	
}

package hbase.dao;

import hbase.modal.Products;
import hbase.utils.HBaseAdminManager;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTableFactory;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

public class ProdutsDao {

	private static HBaseAdmin hBaseAdmin;
	private static HTableFactory factory = new HTableFactory();
	private static HTableInterface table;
	
	public ProdutsDao(){
		
		
		
		
	}
	
	
public Products create(Products product){
		
		return product;
	}

	public Products save(Products product) throws Exception {
		    Put p = new Put(Bytes.toBytes(product.getActivity_id()));
		     
		    Field[] fields=product.getClass().getDeclaredFields();
		    int qualifier=0;
		    for(Field field:fields){
		    	field.setAccessible(true);
	 
		    	p.add(Bytes.toBytes(field.getName()), Bytes.toBytes(++qualifier), Bytes.toBytes(field.get(product).toString()));
		    }
		    
	       // p.add(family1, qualifier1, cellData);
	       // p.add(family1, qualifier2, cellData);
	       table.put(p);
		return product;
	}
	
	public Products update(Products product){
		
		return product;
	}
   public Products delete(Products product){
		
		return product;
	}
   
 
		
	static{
		
		
		 try {
		 Class clas=Products.class;
		 Field[] fields= clas.getDeclaredFields();
 
		 ByteArrayOutputStream baos = new ByteArrayOutputStream();
		 DataOutputStream out = new DataOutputStream(baos);
		 out.writeUTF(ProdutsDao.class.getName().toLowerCase());
		 for(Field field:fields){
			  out.writeUTF(field.getName());
		 }
		 //byte [] tableStructure=baos.toByteArray();
		 byte [] tableStructure=Bytes.toBytes("products"),activity_id =Bytes.toBytes("activity_id"),
						 product_id =Bytes.toBytes("product_id"),
								 Product_name =Bytes.toBytes("Product_name"),
										 uuid =Bytes.toBytes("uuid"),
												 activity_date =Bytes.toBytes("activity_date");
		 
 									  
		 
 
		 hBaseAdmin=HBaseAdminManager.getHBaseAdmin();
		 
		 HTableDescriptor desc = new HTableDescriptor(tableStructure);
		 
		 
		/* try{
		 if(!desc.isMetaTable(tableStructure)){
			 for(Field field:fields){
				 desc.addFamily(new HColumnDescriptor(field.getName()));
			 }
				hBaseAdmin.createTable(desc);
		 }
		 }catch(Exception e1){e1.printStackTrace();}*/
		 table = factory.createHTableInterface(HBaseAdminManager.getConfiguration(),tableStructure);
		 
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	
	}
	
	
	}
	
	public static void main(String[] args) throws Exception 
	{
		Products product=new Products();
		product.setApi_key("API+12121212121212121");
		product.setActivity_id("728172871872781");
		product.setActivity_date(new Date());
		product.setProduct_id("318271872");
		product.setProduct_name("Name12092091");
		product.setStatus("uqyw");
		product.setUuid("121828718271872812");
		
		ProdutsDao produtsDao=new ProdutsDao();
		produtsDao.save(product);
	 
	}	 
	 
	 
}